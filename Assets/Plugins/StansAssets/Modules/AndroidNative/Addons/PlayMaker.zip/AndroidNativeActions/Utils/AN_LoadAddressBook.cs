﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Others")]
	public class AN_LoadAddressBook : FsmStateAction {
				
		public override void OnEnter() {
			ImmersiveMode.Instance.EnableImmersiveMode();
			if(AddressBookController.isLoaded)
				OnAddressBookLoaded();
			else {
				AddressBookController.OnContactsLoadedAction += OnAddressBookLoaded;
			}

		}

		public void OnAddressBookLoaded() {
			AddressBookController.OnContactsLoadedAction -= OnAddressBookLoaded;
			Finish();
		}
	}
}


