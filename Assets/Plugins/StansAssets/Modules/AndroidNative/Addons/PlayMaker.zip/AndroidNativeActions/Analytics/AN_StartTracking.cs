﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_StartTracking : FsmStateAction {

		public override void OnEnter() {
			AndroidGoogleAnalytics.Instance.StartTracking ();

			Finish ();
		}

	}
}
