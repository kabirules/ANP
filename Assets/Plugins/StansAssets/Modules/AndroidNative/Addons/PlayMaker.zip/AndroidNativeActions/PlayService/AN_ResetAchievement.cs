﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - PlayService")]
	public class AN_ResetAchievement : FsmStateAction {

		public FsmString AchievementId;
		
		public override void OnEnter() {
			GooglePlayManager.Instance.ResetAchievement(AchievementId.Value);
			Finish();
		}
	}
}
