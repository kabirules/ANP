﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_ClearKey : FsmStateAction {

		public FsmString key;

		public override void OnEnter() {
			AndroidGoogleAnalytics.Instance.ClearKey (key.Value);

			Finish ();
		}
	}
}
