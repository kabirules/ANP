﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - PlayService")]
	public class AN_SubscribeToGiftsActions : FsmStateAction {
		
		public FsmEvent giftResultReceived;
		public FsmEvent pendingGameRequestDetected;

		public FsmBool showInboxRequestDetected;
		public FsmString code;
		public FsmString[] receivedGiftsPlayload;

		public FsmString reseivedgiftPlayLoad;


		public override void OnEnter() {		
			GooglePlayManager.ActionSendGiftResultReceived += OnGiftResult;
			GooglePlayManager.ActionPendingGameRequestsDetected += OnPendingGiftsDetected;
			GooglePlayManager.ActionGameRequestsAccepted += OnGameRequestAccepted;
		}
	
		private void OnGiftResult(GooglePlayGiftRequestResult result) {
			GooglePlayManager.ActionSendGiftResultReceived -= OnGiftResult;


			this.code.Value = result.code.ToString();

			Fsm.Event(giftResultReceived);
		}

		private void OnPendingGiftsDetected(List<GPGameRequest> r) {
			GooglePlayManager.ActionPendingGameRequestsDetected -= OnPendingGiftsDetected;

			if (showInboxRequestDetected.Value) {
				GooglePlayManager.Instance.ShowRequestsAccepDialog();
			}

			Fsm.Event(pendingGameRequestDetected);
		}

		private void OnGameRequestAccepted(List<GPGameRequest> gifts) {
			receivedGiftsPlayload = new FsmString[]{};
			for(int i = 0; i < gifts.Count; i++) {
				receivedGiftsPlayload[i] = gifts[i].playload;
			}
		}
	}
}