﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_SetKey : FsmStateAction {

		public FsmString key;
		public FsmString value;

		public override void OnEnter() {
			AndroidGoogleAnalytics.Instance.SetKey (key.Value, value.Value);

			Finish ();
		}
	}
}
