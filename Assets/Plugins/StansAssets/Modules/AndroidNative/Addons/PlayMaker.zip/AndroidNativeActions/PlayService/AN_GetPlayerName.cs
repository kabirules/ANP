﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Android Native - PlayService")]
	public class AN_GetPlayerName : FsmStateAction {

		public FsmEvent Success;
		public FsmEvent Fail;

		public FsmString PlayerName;

		public override void OnEnter() {
			if (GooglePlayManager.Instance.player != null) {
				PlayerName.Value = GooglePlayManager.Instance.player.name;

				Fsm.Event(Success);
				Finish();
			} else {
				Fsm.Event(Fail);
				Finish();
			}
		}
	}

}
