﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_CreateTransaction : FsmStateAction {

		public FsmString transactionId;
		public FsmString affiliation;
		public FsmFloat revenue;
		public FsmFloat tax;
		public FsmFloat shipping;
		public FsmString currencyCode;

		public override void OnEnter() {
			AndroidGoogleAnalytics.Instance.CreateTransaction (transactionId.Value, affiliation.Value, revenue.Value, tax.Value, shipping.Value, currencyCode.Value);

			Finish ();
		}
	}
}
