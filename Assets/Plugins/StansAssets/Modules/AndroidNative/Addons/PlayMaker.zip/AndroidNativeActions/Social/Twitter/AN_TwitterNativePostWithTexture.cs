using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterNativePostWithTexture : FsmStateAction {

		public FsmString message;
		public FsmString caption;
		public FsmTexture texture;

		public override void OnEnter() {
			AndroidSocialGate.StartShareIntent (caption.Value, message.Value, texture.Value as Texture2D, "twi");
			Finish();
		}
	}
}


