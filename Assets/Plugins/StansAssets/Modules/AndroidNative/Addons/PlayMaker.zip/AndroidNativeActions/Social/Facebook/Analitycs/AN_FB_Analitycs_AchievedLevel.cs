﻿using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_Analitycs_AchievedLevel : FsmStateAction {

		public FsmInt level;

		public override void OnEnter() {
			//The user has achieved a level in the app.
			SPFacebookAnalytics.AchievedLevel (level.Value);
			Finish ();
		}
		
	}
}