﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_SendEvent : FsmStateAction {

		public FsmString category;
		public FsmString action;
		public FsmString label;
		public FsmInt value;

		public override void OnEnter() {
			if (value != null) {
				AndroidGoogleAnalytics.Instance.SendEvent (category.Value, action.Value, label.Value, (long)value.Value);
			} else {
				AndroidGoogleAnalytics.Instance.SendEvent (category.Value, action.Value, label.Value);
			}

			Finish ();
		}

	}
}
