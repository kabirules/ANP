﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_SetTrackerId : FsmStateAction {

		public FsmString trackerId;

		public override void OnEnter() {
			if (trackerId != null) {
				AndroidGoogleAnalytics.Instance.SetTrackerID (trackerId.Value);
			}

			Finish ();
		}

	}
}
