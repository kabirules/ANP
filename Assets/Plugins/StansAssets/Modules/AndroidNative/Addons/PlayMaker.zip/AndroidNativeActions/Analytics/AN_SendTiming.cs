﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	[ActionCategory("Android Native - Analytics")]
	public class AN_SendTiming : FsmStateAction {

		public FsmString category;
		public FsmInt intervalInMilliseconds;
		public FsmString name;
		public FsmString label;

		public override void OnEnter() {
			AndroidGoogleAnalytics.Instance.SendTiming (category.Value, (long)intervalInMilliseconds.Value, name.Value, label.Value);

			Finish ();	
		}

	}
}
